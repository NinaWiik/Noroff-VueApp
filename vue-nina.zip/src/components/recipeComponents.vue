<template>
    <div class="[ card ]">
        <div class="[ row ]">
            <div class="[ col-sm-4 ]">
            <div class="[ col-sm-4 ]"><img :src="jobImg" /><br /><br /> <br /></div>
            <div class="[ col-sm-4 ]"></div>
        </div>
            <div class="[ card--information ]"><br />
                            <b>Title: </b>{{title}}<br />
                            <b>Ingredients: </b>{{ingredients}}<br />
                            <b>Website: </b><a :href="website" target="_blank">Click Here</a><br />
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'recipeComponents',
    props: ['jobImg','title','version','ingredients','website'],
}
</script>

<style scoped>
.card{
    border: solid 1px black;
    border-radius: 4px;
    padding: 0px 20px 30px;
    margin-top: 30px
}

.card img{
    width: 100%;
    padding-top: 20px;
}

</style>