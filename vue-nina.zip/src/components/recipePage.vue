<template>
    <div class="[ row ]">
        <div v-for="recipe in recipes" class="[ col-sm-12 ]">
            <recipeComponent    v-bind:jobImg="recipe.tumbnail"
                                    v-bind:title="recipe.title"
                                    v-bind:ingredients="recipe.ingredients"
                                    v-bind:website="recipe.href"

            ></recipeComponent>
        </div>
    </div>
</template>

<script>
import recipeComponent from './recipeComponents.vue'

export default {
    name: 'recipePage',
    components: {
        recipeComponent
    },
    data(){
        return{
            recipes: []
        }
    },
    mounted() {
    const convensionUrl = 'https://cors-anywhere.herokuapp.com/';
    const url = 'http://www.recipepuppy.com/api';

        fetch(convensionUrl + url)
        .then(function(response) {
            return response.json();
        })
        .then(function(result) {
            app.jobs = result;
        })
    }
}
</script>